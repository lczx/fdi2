package eqsolver;

public class EquationException extends Exception{

	private static final long serialVersionUID=0;
	
	public EquationException(String message) {
		super(message);
	}
	
}
