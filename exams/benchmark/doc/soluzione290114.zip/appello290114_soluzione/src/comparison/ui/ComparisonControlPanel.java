package comparison.ui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import comparison.ComparisonModel;

public class ComparisonControlPanel extends JPanel{
	
	private static final long serialVersionUID = 0;

	private ComparisonModel model;
	
	public ComparisonControlPanel(ComparisonModel comparisonModel) {
		
		this.model=comparisonModel;
		
		setLayout(new GridLayout(3,1));
		
		JLabel label=new JLabel("N=");
		add(label);
		
		final JTextField field=new JTextField();
		field.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				try {
					int N=Integer.parseInt(field.getText());
					model.setN(N);
				} catch (NumberFormatException e1) {
					//no need to do anything.
					//just, setN is not called
				}
			}
		});
		add(field);
		
		JButton button=new JButton("Execute");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				model.execute();
			}
		});
		add(button);
	}
}
