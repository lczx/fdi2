package comparison.ui;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import comparison.ComparisonModel;

public class MainComparisonUI {

	public static void main(String[] args) {
		
		ComparisonModel model=new ComparisonModel();
		
		ComparisonControlPanel control=new ComparisonControlPanel(model);
		
		ComparisonMenu menu =new ComparisonMenu(model);
		
		ComparisonViewPanel view =new ComparisonViewPanel(model);
		
		JFrame frame=new JFrame();
		frame.setTitle("Comparisons");
		frame.setSize(400,300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel mainPanel=new JPanel();
		mainPanel.setLayout(new GridLayout(2,1));
		mainPanel.add(control);
		mainPanel.add(view);
		
		frame.getContentPane().add(mainPanel);
		
		frame.setJMenuBar(menu);
		
		frame.setVisible(true);
	}
	
}
