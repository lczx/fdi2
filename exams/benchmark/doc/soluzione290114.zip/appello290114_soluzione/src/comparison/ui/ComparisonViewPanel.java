package comparison.ui;

import java.awt.GridLayout;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JLabel;
import javax.swing.JPanel;

import comparison.ComparisonModel;
import comparison.time.TimeFormatter;

public class ComparisonViewPanel extends JPanel implements Observer{
	
	private static final long serialVersionUID = 0;

	private JLabel nLabel;
	private JLabel label1;
	private JLabel label2;
	private ComparisonModel model;
	
	private TimeFormatter formatter=new TimeFormatter();
	
	public ComparisonViewPanel(ComparisonModel model) {
		
		this.model=model;
		model.addObserver(this);
		
		setLayout(new GridLayout(3,1));
		label1=new JLabel();
		label2=new JLabel();
		nLabel=new JLabel();
		add(nLabel);
		add(label1);
		add(label2);
		
	}
	
	@Override
	public void update(Observable o, Object arg) {
		nLabel.setText("N = "+model.getN());
		if(model.getActualComparison()!=null){
			label1.setText(model.getActualComparison().getName1()+" took "+formatter.getFormat(model.getTime1()));
			label2.setText(model.getActualComparison().getName2()+" took "+formatter.getFormat(model.getTime2()));	
		}else{
			label2.setText("Select a Comparison");
		}
	}
	
}
