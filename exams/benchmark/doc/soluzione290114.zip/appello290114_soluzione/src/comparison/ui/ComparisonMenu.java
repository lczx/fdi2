package comparison.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import comparison.Comparison;
import comparison.ComparisonModel;
import comparison.operations.IntegerArraysSort;
import comparison.operations.IntegerListAdd;
import comparison.operations.IntegerListBubbleSort;
import comparison.operations.IntegerListCollectionsBinarySearch;
import comparison.operations.IntegerListCollectionsSort;
import comparison.operations.IntegerListIndexOfSearch;
import comparison.operations.StringListCollectionSort;

public class ComparisonMenu extends JMenuBar{
	
	private static final long serialVersionUID = 0;

	//Note: when you want to add/redefine comparisona, you need only to reconfigure this list!!
	private Comparison[] comparisons={
		new Comparison("ArrayList", new IntegerListAdd(new ArrayList<Integer>()), 
					   "LinkedList", new IntegerListAdd(new LinkedList<Integer>())),
		new Comparison("ArrayList", new IntegerListCollectionsSort(new ArrayList<Integer>()), 
			   		"int[]", new IntegerArraysSort()),
   		new Comparison("Collections Sort", new IntegerListCollectionsSort(new ArrayList<Integer>()), 
		   		"Bubble Sort", new IntegerListBubbleSort(new ArrayList<Integer>())),
   		new Comparison("ArrayList", new StringListCollectionSort(new ArrayList<String>()), 
		   		"LinkedList", new StringListCollectionSort(new ArrayList<String>())),
   		new Comparison("indexof", new IntegerListIndexOfSearch(new ArrayList<Integer>()), 
		   		"binarySearch", new IntegerListCollectionsBinarySearch(new ArrayList<Integer>())),
   		new Comparison("ArrayList", new IntegerListIndexOfSearch(new ArrayList<Integer>()), 
		   		"LinkedList", new IntegerListIndexOfSearch(new LinkedList<Integer>())),
	};
	
	private String[] comparisonsNames={
			"Lists Add",
			"Collections vs Arrays Sort",
			"Collection vs BubbleSort",
			"Strings List Sort",
			"indexof vs binarySearch",
			"indexof on ArrayList and LinkedList"
	};
	
	
	private ComparisonModel comparisonModel;
	
	public ComparisonMenu(ComparisonModel model) {
		
		this.comparisonModel=model;
		
		JMenu select=new JMenu("Comparison");
		
		for (int i = 0; i < comparisons.length; i++) {
			
			final int index = i;
			JMenuItem item=new JMenuItem(comparisonsNames[i]);
			item.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					comparisonModel.setActualComparison(comparisons[index]);
				}
			});
			
			select.add(item);
		}
		
		add(select);
	
	}
}
