package comparison;

/**
 * A Couple of Operation to be Compared
 * 
 * @author Alessandro Martinelli
 *
 */
public class Comparison {

	private Operation operation1;
	private Operation operation2;
	private String name1;
	private String name2;
	
	/**
	 * @param name1 a Name for the first Operation
	 * @param operation1 the first Operation
	 * @param name2 a Name for the second Operation
	 * @param operation2 the second Operation
	 */
	public Comparison(String name1, Operation operation1, String name2, Operation operation2) {
		super();
		this.name1 = name1;
		this.operation1 = operation1;
		this.name2 = name2;
		this.operation2 = operation2;
	}

	/**
	 * A Very important method containing 
	 * the code required for time evaluation.
	 * 
	 * This is a (D.P.) Template Method, since it is based upon the abstraction
	 * in Operation.
	 * 
	 * @param operation the operation to be tested
	 * @param N the number of elements on which the operation should be performed
	 * @return the time it tooks to call operation.execute()
	 */
	public long evaluate(Operation operation,int N){
		operation.prepare(N);
		long time1=System.nanoTime();
		operation.execute();
		long time2=System.nanoTime();
		return time2-time1;
	}
	
	public long evaluateTime1(int N){
		return evaluate(operation1, N);
	}
	
	public long evaluateTime2(int N){
		return evaluate(operation2, N);
	}
	
	public Operation getOperation1() {
		return operation1;
	}

	public void setOperation1(Operation operation1) {
		this.operation1 = operation1;
	}

	public Operation getOperation2() {
		return operation2;
	}

	public void setOperation2(Operation operation2) {
		this.operation2 = operation2;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getName2() {
		return name2;
	}

	public void setName2(String name2) {
		this.name2 = name2;
	}

	
}
