package comparison;

/**
 * One of the operations we want to test.
 * 
 * @author Alessandro Martinelli
 */
public interface Operation {

	/**
	 * Prepare the operation to be performed, assigning an integer number
	 * N which is the number of elements to be used.
	 * @param N the Number of elements on which the operation will perform
	 */
	public void prepare(int N);

	/**
	 * Execute the operation
	 */
	public void execute();
}
