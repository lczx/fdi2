package comparison.operations;

import java.util.Collections;
import java.util.List;

/**
 * An operation used to test the method Collections.binarySearch
 * 
 * @author Alessandro Martinelli
 */
public class IntegerListCollectionsBinarySearch extends IntegerListOperation{

	private int max;
	
	/**
	 * @param list the instance of List on which the test will be performed
	 */
	public IntegerListCollectionsBinarySearch(List<Integer> list) {
		super(list);
	}

	@Override
	public void prepare(int N) {
		fillList(N);
		max=Collections.max(getList());
		Collections.sort(getList());
	}
	
	@Override
	public void execute() {
		Collections.binarySearch(getList(), max);
	}
}
