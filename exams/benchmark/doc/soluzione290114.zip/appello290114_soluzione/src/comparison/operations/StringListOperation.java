package comparison.operations;

import java.util.List;

import comparison.Operation;

/**
 * A generic class for Operation executing tests on Lists of Strings
 * 
 * @author Alessandro Martinelli
 */
public class StringListOperation implements Operation{

	private List<String> list;

	/**
	 * @param list an implementation of List used to execute the test
	 */
	public StringListOperation(List<String> list) {
		super();
		this.list = list;
	}
	
	public List<String> getList() {
		return list;
	}

	@Override
	public void prepare(int N) {
		//To Override
	}

	/**
	 * Fill this list with N randomly generated Strings
	 * @param N
	 */
	public void fillList(int N) {
		list.clear();
		for (int i = 0; i < N; i++) {
			char[] elements=new char[6];
			for (int j = 0; j < elements.length; j++) {
				elements[j]=(char)('a'+(Math.random()*('z'-'a')));
			}
			list.add(new String(elements));
		}
	}
	
	@Override
	public void execute() {
		//To Override
	}
}
