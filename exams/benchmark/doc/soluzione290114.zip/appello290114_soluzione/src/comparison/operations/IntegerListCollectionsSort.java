package comparison.operations;

import java.util.Collections;
import java.util.List;

/**
 * An operation used to test Collections.sort
 * 
 * @author Alessandro Martinelli
 */
public class IntegerListCollectionsSort extends IntegerListOperation{

	/**
	 * @param list the instance of List used to execute this test
	 */
	public IntegerListCollectionsSort(List<Integer> list) {
		super(list);
	}
	
	@Override
	public void prepare(int N) {
		fillList(N);
	}

	@Override
	public void execute() {
		Collections.sort(getList());
	}
	
}
