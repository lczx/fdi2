package comparison.operations;

import java.util.Arrays;

import comparison.Operation;

/**
 * An operation using Arrays.sort to sort an array of ints.
 * 
 * @author Alessandro Martinelli
 */
public class IntegerArraysSort implements Operation{

	private int[] numbers;
	
	@Override
	public void execute() {
		Arrays.sort(numbers);
	}
	
	@Override
	public void prepare(int N) {
		numbers=new int[N];
		for (int i = 0; i < N; i++) {
			numbers[i]=((int)(Math.random()*10000));
		}
	}
}
