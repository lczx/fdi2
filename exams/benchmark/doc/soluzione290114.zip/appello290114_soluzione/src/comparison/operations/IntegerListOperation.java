package comparison.operations;

import java.util.List;

import comparison.Operation;

/**
 * Common Class for all the operations based upon Lists of Integers
 * 
 * @author Alessandro Martinelli
 */
public class IntegerListOperation implements Operation{

	private List<Integer> list;

	/**
	 * @param list the implementation of List used to execute the tests
	 */
	public IntegerListOperation(List<Integer> list) {
		super();
		this.list = list;
	}
	
	public List<Integer> getList() {
		return list;
	}

	@Override
	public void prepare(int N) {
		//To Override
	}

	/**
	 * Fill the list with N random numbers
	 * @param N
	 */
	public void fillList(int N) {
		list.clear();
		for (int i = 0; i < N; i++) {
			list.add((int)(10000*Math.random()));
		}
	}
	
	@Override
	public void execute() {
		//To Override
	}
	
}
