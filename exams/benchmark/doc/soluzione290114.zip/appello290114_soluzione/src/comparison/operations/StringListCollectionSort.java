package comparison.operations;

import java.util.Collections;
import java.util.List;

/**
 * A test for Collections.sort an Strings List
 * 
 * @author Alessandro Martinelli
 */
public class StringListCollectionSort extends StringListOperation{

	/**
	 * @param list an implementation of List used to execute the test
	 */
	public StringListCollectionSort(List<String> list) {
		super(list);
	}

	@Override
	public void prepare(int N) {
		fillList(N);
	}
	
	@Override
	public void execute() {
		Collections.sort(getList());
	}
}
