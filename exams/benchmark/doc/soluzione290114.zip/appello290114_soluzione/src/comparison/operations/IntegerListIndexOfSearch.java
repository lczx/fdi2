package comparison.operations;

import java.util.Collections;
import java.util.List;

/**
 * An Operation used to test indexOf
 * 
 * @author Alessandro Martinelli
 */
public class IntegerListIndexOfSearch extends IntegerListOperation{

	private int max;
	
	/**
	 * @param list an implementation of List<Integer> used to execute this test
	 */
	public IntegerListIndexOfSearch(List<Integer> list) {
		super(list);
	}

	@Override
	public void prepare(int N) {
		fillList(N);
		max=Collections.max(getList());
		Collections.sort(getList());
	}
	
	@Override
	public void execute() {
		getList().indexOf(max);
	}
}
