package comparison.operations;

import java.util.List;

/**
 * An operation using add to add elements to a list
 * 
 * @author Alessandro Martinelli
 */
public class IntegerListAdd extends IntegerListOperation{

	private int N;
	
	/**
	 * @param list the instance of List which will be used for testing
	 */
	public IntegerListAdd(List<Integer> list) {
		super(list);
	}
	
	@Override
	public void prepare(int N) {
		this.N=N;
		getList().clear();
	}

	@Override
	public void execute() {
		List<Integer> list=getList();
		for (int i = 0; i < this.N; i++) {
			list.add(0);
		}
	}
	
}
