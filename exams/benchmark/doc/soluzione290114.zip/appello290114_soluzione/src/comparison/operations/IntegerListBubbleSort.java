package comparison.operations;

import java.util.List;

/**
 * An operation using the Bubble Sort Algorithm to sort a list of Integers
 * 
 * @author Alessandro Martinelli
 */
public class IntegerListBubbleSort extends IntegerListOperation{

	/**
	 * @param list the instance of List on which the operation will be performed
	 */
	public IntegerListBubbleSort(List<Integer> list) {
		super(list);
	}
	
	@Override
	public void prepare(int N) {
		fillList(N);
	}

	@Override
	public void execute() {
		List<Integer> list=getList();
		for (int i = 0; i < list.size(); i++) {
			for (int j = i+1; j < list.size(); j++) {
				if(list.get(i)>list.get(j)){
					int temp=list.get(i);
					list.set(i, list.get(j));
					list.set(j, temp);
				}
			}
		}
	}
	
}
