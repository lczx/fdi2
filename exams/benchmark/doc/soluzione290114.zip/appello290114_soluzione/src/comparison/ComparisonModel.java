package comparison;

import java.util.Observable;

/**
 * A Model for the Comparison Software
 * 
 * @author Alessandro Martinelli
 */
public class ComparisonModel extends Observable{
	
	/* Max value for N. It has been assigned 10000 (instead of 100000 as it was in the text of the exam), 
	 * since with greater values some Operations will take too much time,
	 * and some students may think the software is crushing ...
	 */
	public static final int MAX_N = 10000;

	private Comparison actualComparison;
	private int N=1;
	private long time1,time2;
	
	/**
	 * Set the actal active comparison
	 * @param actualComparison
	 */
	public void setActualComparison(Comparison actualComparison) {
		this.actualComparison = actualComparison;
		execute();
	}
	
	public Comparison getActualComparison() {
		return actualComparison;
	}
	
	public int getN() {
		return N;
	}
	
	/**
	 * Set the number of elements on which comparisons should be performed
	 * @param n
	 */
	public void setN(int n) {
		if(n>MAX_N)
			n=MAX_N;
		if(n<1)
			n=1;
		N = n;
		update();
	}
	
	public long getTime1() {
		return time1;
	}
	
	public long getTime2() {
		return time2;
	}
	
	/**
	 * Executes the evaluation of both the two operations and 
	 * updates this model
	 */
	public void execute(){
		if(actualComparison!=null){
			time1=actualComparison.evaluateTime1(N);
			time2=actualComparison.evaluateTime2(N);	
		}
		update();
	}
	
	/**
	 * Updates this model
	 */
	public void update(){
		setChanged();
		notifyObservers();
	}
}
