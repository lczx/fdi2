package comparison.time;

/**
 * Tool responsible for Time format
 * 
 * @author Alessandro Martinelli
 */
public class TimeFormatter {

	/**
	 * Create a String representing a time interval form its representation ad number of nanoseconds. 
	 * @param time the number of nanosecond
	 * @return a representation as String of the time interval
	 */
	public String getFormat(long time){
		int part1=(int)(time/1000000);
		int part2=(int)(time%1000000);
		part2=(int)(part2/1000);
		return part1+"."+part2+" ms";
	}
	
}
