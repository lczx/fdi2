package tests;

import java.util.ArrayList;

import comparison.operations.IntegerListBubbleSort;

public class BubbleSortTest {

	public static void main(String[] args) {
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		
		IntegerListBubbleSort bubbleSort=new IntegerListBubbleSort(list);
		
		bubbleSort.prepare(30);
		bubbleSort.execute();
		
		System.out.println(list);
	}
}
