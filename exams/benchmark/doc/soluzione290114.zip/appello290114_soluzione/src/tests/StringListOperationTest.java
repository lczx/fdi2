package tests;

import java.util.ArrayList;

import comparison.operations.StringListOperation;

public class StringListOperationTest {

	public static void main(String[] args) {
		
		ArrayList<String> list=new ArrayList<String>();
		
		StringListOperation stringList=new StringListOperation(list);
		
		//just test fill List
		stringList.fillList(20);
		
		System.out.println(list);
	}
}
