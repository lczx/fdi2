package tests;

import java.util.Collection;

import verificastoria.Evento;
import verificastoria.FiltroPaese;
import verificastoria.FiltroTutti;
import verificastoria.Paese;
import verificastoria.Verifica;

/**
 * Test inserimento e Ordinamento
 * 
 * @author Alessandro 
 */
public class Test02 {

	public static void main(String[] args) {
		
		Verifica modello = new Verifica();
		
		modello.add(new Evento("AAAA", 1912, Paese.Italia));
		modello.add(new Evento("BBBB", 1912, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1912, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1920, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1911, Paese.Italia));
		modello.add(new Evento("CCCC", 1910, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1909, Paese.Francia));

		System.out.println("Filtro Paese");
		
		modello.setFiltro(new FiltroPaese(Paese.GermaniaPrussia));
		
		Collection<Evento> eventi = modello.getElencoFiltrato();
		for (Evento evento : eventi) {
			System.out.println(evento);
		}
		
		System.out.println("Filtro Tutti");
		
		modello.setFiltro(new FiltroTutti());
		
		eventi = modello.getElencoFiltrato();
		for (Evento evento : eventi) {
			System.out.println(evento);
		}
		
	}
}
