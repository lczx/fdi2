package tests;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;

import utils.PannelloControllo;
import utils.EsportaMenu;
import utils.FiltriMenu;
import utils.PannelloElencoEventi;
import verificastoria.FiltroTutti;
import verificastoria.Verifica;

public class Test extends JFrame{
	
	private static final long serialVersionUID = 1L;
	
	public static void main(String[] args) {

		JFrame frame = new JFrame();
		
		Verifica verifica = new Verifica();
		verifica.setFiltro(new FiltroTutti());
		PannelloElencoEventi elencoEventi = new PannelloElencoEventi(verifica);
		PannelloControllo controllo = new PannelloControllo(verifica);
		
		JPanel mainPanel=new JPanel();
		mainPanel.setLayout(new GridLayout(2,1));
		mainPanel.add(controllo);
		mainPanel.add(elencoEventi);
		
		frame.getContentPane().add(mainPanel);
		
		JMenuBar menubar=new JMenuBar();
			menubar.add(new EsportaMenu(verifica));
			menubar.add(new FiltriMenu(verifica));
		frame.setJMenuBar(menubar);
		
		frame.setSize(800,600);
		frame.setTitle("Storia");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
}
