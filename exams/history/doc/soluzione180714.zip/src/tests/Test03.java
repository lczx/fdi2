package tests;

import verificastoria.Evento;
import verificastoria.Paese;
import verificastoria.Verifica;
import verificastoria.report.ReportVerifica;

/**
 * Test inserimento e Ordinamento
 * 
 * @author Alessandro 
 */
public class Test03 {

	public static void main(String[] args) {
		
		Verifica modello = new Verifica();
		
		modello.add(new Evento("AAAA", 1912, Paese.Italia));
		modello.add(new Evento("BBBB", 1912, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1912, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1920, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1911, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1910, Paese.GermaniaPrussia));
		modello.add(new Evento("CCCC", 1909, Paese.GermaniaPrussia));
		
		(new ReportVerifica(modello.getElencoCompleto())).write("prova.txt");
	}
}
