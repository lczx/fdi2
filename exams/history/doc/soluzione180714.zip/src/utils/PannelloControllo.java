package utils;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import verificastoria.Evento;
import verificastoria.Paese;
import verificastoria.Verifica;

public class PannelloControllo extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private Verifica verifica;
	
	private JButton inserisci;
	
	private JTextField nomeEvento;
	private JTextField annoEvento;	
	private JComboBox<Paese> comboBox;
	
	public PannelloControllo(Verifica m) {
		super();
		this.setVerifica(m);
		
		setLayout(new GridLayout(4,1));
		
		nomeEvento = new JTextField("Nome Evento", 50);
		add(nomeEvento);
		
		annoEvento = new JTextField("Anno Evento", 50);
		add(annoEvento);
		
		Paese[] luoghi = Paese.values();
		comboBox = new JComboBox<Paese>(luoghi);
		add(comboBox);
		
		inserisci = new JButton("Inserisci Evento");
		inserisci.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				verifica.add(new Evento(nomeEvento.getText(), 
										new Integer(annoEvento.getText()), 
										(Paese)comboBox.getSelectedItem()));
			}
		});
		add(inserisci);
	}

	public void setVerifica(Verifica verifica) {
		this.verifica = verifica;
	}

}
