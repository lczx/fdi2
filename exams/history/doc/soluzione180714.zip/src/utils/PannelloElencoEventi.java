package utils;

import java.awt.BorderLayout;
import java.util.Collection;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import verificastoria.Evento;
import verificastoria.Verifica;

public class PannelloElencoEventi extends JPanel implements Observer {

	private Verifica verifica;
	
	private JTextArea risultato;
	
	public PannelloElencoEventi(Verifica m) {
		super();
		this.verifica = m;
		setLayout(new BorderLayout());
		risultato = new JTextArea("--");
		add(risultato);
		m.addObserver(this);
	}

	public void setVerifica(Verifica verifica) {
		this.verifica = verifica;
	}
		
	private static final long serialVersionUID = 1L;
	
	private String writeEventoGui(Evento evento){
		return ""+evento.getAnno()+"("+evento.getLuogo()+"):"+evento.getNome();
	}

	@Override
	public void update(Observable o, Object arg) {
		
		Collection<Evento> eventi=verifica.getElencoFiltrato();
		String messaggio="";
		for (Evento evento : eventi) {
			messaggio= messaggio+writeEventoGui(evento)+"\n";
		}
		risultato.setText(messaggio);
	}

}
