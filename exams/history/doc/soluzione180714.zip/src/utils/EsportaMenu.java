package utils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

import verificastoria.Verifica;
import verificastoria.report.ReportVerifica;

public class EsportaMenu extends JMenu{

	private static final long serialVersionUID = 1L;
	
	public EsportaMenu(final Verifica verifica) {
		super("File");
		
		JMenuItem filtroTutti=new JMenuItem("Esporta");
		filtroTutti.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				(new ReportVerifica(verifica.getElencoCompleto())).write("prova.txt");
			}
		});
		add(filtroTutti);
	}
	
}
