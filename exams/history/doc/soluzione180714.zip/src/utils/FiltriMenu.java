package utils;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

import verificastoria.FiltroPaese;
import verificastoria.FiltroTutti;
import verificastoria.Paese;
import verificastoria.Verifica;

public class FiltriMenu extends JMenu{

	private static final long serialVersionUID = 1L;
	
	public FiltriMenu(final Verifica verifica) {
		super("Filtro");
		
		JMenuItem filtroTutti=new JMenuItem("Tutti");
		filtroTutti.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				verifica.setFiltro(new FiltroTutti());
				//FiltriMenu.this.filtro.setFiltro(new FiltroTutti());
			}
		});
		add(filtroTutti);
		
		Paese[] paesi=Paese.values();
		for (int i = 0; i < paesi.length; i++) {
			JMenuItem filtroPaese=new JMenuItem(paesi[i].getName());
			final Paese paese=paesi[i];
			filtroPaese.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					verifica.setFiltro(new FiltroPaese(paese));
					//FiltriMenu.this.filtro.setFiltro(new FiltroPaese(paese));
				}
			});
			add(filtroPaese);
		}
	}
}
