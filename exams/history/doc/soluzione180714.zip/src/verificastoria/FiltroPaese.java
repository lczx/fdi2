package verificastoria;


/**
 * Filtra gli eventi avvenuti in un certo paese
 * 
 * @author Alessandro
 */
public class FiltroPaese implements IFiltroEvento{

	private Paese paese;
	
	public FiltroPaese(Paese paese) {
		super();
		this.paese = paese;
	}

	@Override
	public boolean tieniEvento(Evento evento) {
		return evento.getLuogo()==paese;
	}
}
