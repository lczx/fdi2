package verificastoria;


/**
 * Un Filtro su Eventi Storici
 * 
 * @author Alessandro
 */
public interface IFiltroEvento {

	/**
	 * Verifica se un Evento soddisfa i criteri per questo filtro 
	 * 
	 * @param evento
	 * @return true se l'Evento soddisfa i criteri per questo filtro
	 */
	public boolean tieniEvento(Evento evento);
}
