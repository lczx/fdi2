package verificastoria;


public class ProxyFiltroEvento implements IFiltroEvento{

	private IFiltroEvento filtro;

	public ProxyFiltroEvento(IFiltroEvento filtro) {
		super();
		this.filtro = filtro;
	}

	public void setFiltro(IFiltroEvento filtro) {
		this.filtro = filtro;
	}
	
	@Override
	public boolean tieniEvento(Evento evento) {
		return filtro.tieniEvento(evento);
	}
}
