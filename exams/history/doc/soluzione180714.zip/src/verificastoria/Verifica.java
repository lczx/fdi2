package verificastoria;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Observable;
import java.util.TreeSet;

/**
 * Descrizione di una Prova di Verifica di Storia
 * 
 * @author Alessandro Martinelli
 */
public class Verifica extends Observable {
	
	private TreeSet<Evento> e=new TreeSet<Evento>();

	private ProxyFiltroEvento filtro=new ProxyFiltroEvento(new FiltroTutti());
	
	public Verifica() {
		super();
	}
	
	public void setFiltro(IFiltroEvento filtro) {
		this.filtro.setFiltro(filtro);
		update();
	}

	public void add(Evento evento){
		e.add(evento);
		update();
	}
	
	public TreeSet<Evento> getElencoCompleto() {
		return e;
	}
	
	public Collection<Evento> getElencoFiltrato(){
		ArrayList<Evento> elencoFiltrato=new ArrayList<Evento>();
		for (Evento evento : e) {
			if(filtro.tieniEvento(evento)){
				elencoFiltrato.add(evento);
			}
		}
		return elencoFiltrato;
	}
	
	public void update(){
		//Collections.sort(e);
		setChanged();
		notifyObservers();
	}

}
