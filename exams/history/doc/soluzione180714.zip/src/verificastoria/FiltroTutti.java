package verificastoria;


/**
 * Un FiltroEvento che accetta qualsiasi tipologia di Evento 
 * 
 * @author Alessandro
 */
public class FiltroTutti implements IFiltroEvento{

	@Override
	public boolean tieniEvento(Evento evento) {
		return true;
	}
}
