package verificastoria;

public enum Paese {
	Italia("Italia"),
	Francia("Francia"),
	GermaniaPrussia("Germania/Prussia"),
	Spagna("Spagna"),
	Austria("Austria"),
	Inghilterra("Inghilterra"),
	Russia("Russia"),
	Altro("Altro");
	
	private String name;
	
	private Paese(String name){
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
}
