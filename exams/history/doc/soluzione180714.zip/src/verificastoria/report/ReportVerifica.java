package verificastoria.report;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import verificastoria.Evento;

public class ReportVerifica {
	
	private Collection<Evento> lines;

	public ReportVerifica(Collection<Evento> lines) {
		super();
		this.lines = lines;
	}
	
	public void write(String filename){
		try {
			FileWriter writer=new FileWriter(filename);
			Iterator<Evento> linesIterator=lines.iterator();
			while(linesIterator.hasNext()){
				writer.write(writeEvento(linesIterator.next())+"\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Descrive un evento in formato stringa per il solo utilizzo all'interno del File di Report
	 * 
	 * Nota : non usare il toString di Evento, che è pensato unicamente per messaggi di Debug 
	 * s
	 * @param evento
	 * @return
	 */
	public String writeEvento(Evento evento){
		return evento.getAnno()+" "+evento.getLuogo()+" "+evento.getNome();
	}
}
