package verificastoria;


/**
 * Descrizione di un Evento Storico
 * 
 * @author Alessandro Martinelli
 */
public class Evento implements Comparable<Evento>{

	private String evento;
	private int anno;
	private Paese luogo;
	
	public Evento(String nome, int anno, Paese luogo) {
		super();
		this.evento = nome;
		this.anno = anno;
		this.luogo = luogo;
	}

	public String getNome() {
		return evento;
	}

	public void setNome(String nome) {
		this.evento = nome;
	}

	public int getAnno() {
		return anno;
	}

	public void setAnno(int anno) {
		this.anno = anno;
	}

	public Paese getLuogo() {
		return luogo;
	}

	public void setLuogo(Paese luogo) {
		this.luogo = luogo;
	}
	
	@Override
	public String toString() {
		return anno+" "+luogo+" "+evento;
	}

	@Override
	public int compareTo(Evento o) {
		//int result = o.anno-anno;
		int result = ((Integer)anno).compareTo((Integer)o.anno);
		if(result==0){
			result = luogo.compareTo(o.luogo);
			if(result==0){
				result = evento.compareTo(o.evento);
			}
		}
		return result;
	}
	
}
